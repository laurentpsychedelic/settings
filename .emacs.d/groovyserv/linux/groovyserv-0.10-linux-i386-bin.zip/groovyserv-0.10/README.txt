See the following URL:
    http://kobo.github.com/groovyserv/
